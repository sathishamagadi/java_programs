package com.employee.empcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpcrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
