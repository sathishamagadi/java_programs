package com.employee.empcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpcrudApplication.class, args);
	}

}
