package com.employee.empcrud.dao;

import java.util.List;

import com.employee.empcrud.entity.Employee;

public interface EmployeeDAO 
{
   //business logic
	
	//crud functions:
	
	public List<Employee>  findAll();
	
	
	public Employee findById(int theId);
	
	public void save(Employee theEmployee);
	
	public void deleteById(int theId);
	

	
}
