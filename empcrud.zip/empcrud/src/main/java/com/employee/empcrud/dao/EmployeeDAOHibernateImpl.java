package com.employee.empcrud.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.employee.empcrud.entity.Employee;

@Repository
public class EmployeeDAOHibernateImpl implements EmployeeDAO 
{
	
	private EntityManager  entityManager;
	
	@Autowired
	EmployeeDAOHibernateImpl(EntityManager  theEntityManager)
	{
		 entityManager     =   theEntityManager;
	}
	

	@Override
	public List<Employee> findAll() {
		
		Session currentSession  =  entityManager.unwrap(Session.class);
		
		Query<Employee> theQuery = currentSession.createQuery("from Employee", Employee.class);
		
		 List<Employee> employees =    theQuery.getResultList();
		
		return employees;
	}

	
	@Override
	public Employee findById(int theId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Employee theEmployee) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteById(int theId) {
		// TODO Auto-generated method stub

	}

}
